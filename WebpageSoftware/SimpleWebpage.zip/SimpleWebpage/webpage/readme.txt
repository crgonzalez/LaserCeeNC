For information on this example refer to:
docs\examples\CC32xx HTTP Server.pdf
or
http://processors.wiki.ti.com/index.php/CC32xx_HTTP_Server