MyProject2 has all the project files needed to start the program in code composer and has some paths
pointing to other example projects in its include section that I have included with it.  

The webpage folder has the html files you'll need to program onto the board with Uniflash.  

Since I've had everything setup from the start, I wouldn't exactly know how to put it back together 
off the top of my head with these files right away since I don't know what it will look like on your
side just opening it in CCS, but if you're trying to run it and having problems let me know so we can
both work through it.																					


Program Operation:

Right now, it does not send that much data over just a few lines or so, and I am working on consistency as 
well.  The main significance of this program is that it shows proof of a working server on the device as 
well as an active communication between the user and the CC3200.  If you wish to run it, make a short .txt
file with a few lines in it very similar to the provided .txt file.  When you run the program, use a terminal
emulator and connect to the device, mysimplelink.net will show a webpage with the option to browse for G-Code 
or submit a file. If you don't pick a file first, an error message will pop up when you try to submit.  Once 
you pick a file and submit, a message will confirm this and the text should print to the terminal after.

-----------------------------------------------------------------------------------------------------------